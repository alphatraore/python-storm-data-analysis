# Python Storm Data Analysis

SAS/Excel ingestion, pandas transformations, storm summaries, Matplotlib figures, and Excel/CSV reporting.

## Reproduce
```bash
python -m pip install -r requirements.txt
python run_notebook.py
```
The runner executes all 80 Python code cells sequentially with Matplotlib Agg and a display shim; it saves outputs in the notebook. No Jupyter kernel is required. You can also open the notebook in Jupyter, starting in the notebooks directory.

## Identity and QC policy
Keep all 3,172 summary records. Complete identifiers combine season, basin, and normalized name and are unique. Exclude 80 incomplete identities and 70 ambiguous season/name candidates from damage-link eligibility; preserve them in audit CSVs. Because the damage source lacks basin, only unique season/name matches are permitted. Enforce many-to-one cardinality; all 38 damage events match without multiplied rows.

Group detail wind by season/basin/name, producing 90 summaries for 2016. Exclude and report 60 observations with incomplete grouping identifiers. Retain 23 missing summary maximum-wind values without imputation. Detail Wind units have not been established from source documentation. Cost comparisons are descriptive and unadjusted for inflation/exposure.

See output/tables/notebook_execution.json and the audit CSVs for execution and join evidence. These are portfolio outputs, not a forecasting model.

Changes in this downloadable source are local to the portfolio package; the linked GitHub repository was not updated automatically.
