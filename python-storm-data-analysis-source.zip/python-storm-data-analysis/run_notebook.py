"""Execute every Python code cell in order without a Jupyter server.
Uses Agg for headless figures and a display shim for tabular previews.
"""
import ast, contextlib, io, json, os, platform, time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
p = Path(__file__).resolve().parent
os.chdir(p/'notebooks')
f = Path('python-storm-data-analysis.ipynb')
n = json.loads(f.read_text())
ns = {'__name__':'__main__', 'display':lambda *args: print(*(str(a) for a in args), sep='\n')}
count = 0
started=time.time()
for cell in n['cells']:
    if cell['cell_type'] != 'code': continue
    source=''.join(cell['source'])
    if not source.strip(): continue
    count+=1
    capture=io.StringIO()
    with contextlib.redirect_stdout(capture):
        tree=ast.parse(source)
        tail=tree.body.pop() if tree.body and isinstance(tree.body[-1],ast.Expr) else None
        exec(compile(tree, f'cell-{count}', 'exec'),ns)
        if tail:
            value=eval(compile(ast.Expression(tail.value),f'cell-{count}','eval'),ns)
            if value is not None: print(value)
    cell['execution_count']=count
    cell['outputs']=[{'output_type':'stream','name':'stdout','text':capture.getvalue().splitlines(keepends=True)}]
f.write_text(json.dumps(n,indent=1))
report={'status':'passed','executed_code_cells':count,'execution_mode':'Sequential Python cell execution with Agg and display shim; no Jupyter kernel','python':platform.python_version(),'elapsed_seconds':round(time.time()-started,2)}
(p/'output/tables/notebook_execution.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
